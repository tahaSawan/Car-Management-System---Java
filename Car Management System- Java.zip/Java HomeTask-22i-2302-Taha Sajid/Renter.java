import java.util.ArrayList;
import java.util.List;

// Base class for Renter
public abstract class Renter {
    private String renterID;
    private String name;
    private String email;
    private String phoneNumber;
    private String address;
    private List<Car> rentedCars;
    private double totalRentalFee;

    //Abstraction - the variables can only be accessed by getter 

    // Constructor
    public Renter(String renterID, String name, String email, String phoneNumber, String address) {
        this.renterID = renterID;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.address = address;
        this.rentedCars = new ArrayList<>();
        this.totalRentalFee = 0.0;
    }

    // Getter and Setter methods
    public String getRenterID() {
        return renterID;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getAddress() {
        return address;
    }

    public double getTotalRentalFee() {
        return totalRentalFee;
    }

    public List<Car> getRentedCars() {
        return rentedCars;
    }

    public void addRentedCar(Car car) {
        rentedCars.add(car);
    }

    public void addRentalFee(double fee) {
        totalRentalFee += fee;
    }

    public void removeRentedCar(Car car) {
        rentedCars.remove(car);
    }

    // Abstract method to calculate discounts or special rates
    public abstract double calculateDiscount(double rentalCost);
}
