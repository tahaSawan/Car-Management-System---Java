// Regular Renter subclass
// Child class of Renter Class
public class RegularRenter extends Renter {
    public RegularRenter(String renterID, String name, String email, String phoneNumber, String address) {
        super(renterID, name, email, phoneNumber, address);
    }

    // No special discount for regular renters
    @Override
    public double calculateDiscount(double rentalCost) {          //Polymorphism
        return rentalCost;
    }
}


