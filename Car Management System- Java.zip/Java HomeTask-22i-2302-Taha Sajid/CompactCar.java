// CompactCar is a child of Car class
// Subclass for Compact Car   - Inheritance
public class CompactCar extends Car {
    // Constructor
    public CompactCar(String carID, String brand, String model, int year, double rentalFee, String plateNumber) {
        super(carID, brand, model, year, rentalFee, plateNumber);
    }

    // Calculate rental cost based on distance traveled - Ploymorphism
    @Override
    public double calculateRentalCost(double distanceTraveled) {
        // Base rent + cost per distance traveled (example: $0.5 per km)
        return getRentalFee() + distanceTraveled * 0.5;
    }

    // Compact cars are not insurable
    @Override
    public boolean isInsurable() {
        return false;
    }

    // No insurance cost for compact cars
    @Override
    public double calculateInsuranceCost() {  //Polymorphism
        return 0.0;
    }

    // Calculate damage cost
    @Override
    public double calculateDamageCost(double damagePercentage) {   //Concept of polymorphism
        // For uninsured cars, full damage cost is applied
        return getRentalFee() * damagePercentage;
    }
}

