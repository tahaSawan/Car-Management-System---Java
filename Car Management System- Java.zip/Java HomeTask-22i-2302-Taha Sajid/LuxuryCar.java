//Luxury class is a child of car class
// Subclass for Luxury Car
public class LuxuryCar extends Car {
    private static final double INSURANCE_RATE = 0.2; // 20% of base rent
    private static final double LUXURY_TAX_RATE = 0.15; // 15% luxury tax

    // Constructor
    public LuxuryCar(String carID, String brand, String model, int year, double rentalFee, String plateNumber) {
        super(carID, brand, model, year, rentalFee, plateNumber);
    }

    // Calculate rental cost based on distance traveled and luxury tax
    @Override
    public double calculateRentalCost(double distanceTraveled) {
        double baseCost = getRentalFee() + distanceTraveled * 1.0; // Luxury cars have higher per km cost
        double luxuryTax = baseCost * LUXURY_TAX_RATE;
        return baseCost + luxuryTax;
    }

    // Luxury cars are insurable
    @Override
    public boolean isInsurable() {
        return true;
    }

    // Calculate insurance cost as a percentage of the base rent
    @Override
    public double calculateInsuranceCost() {
        return getRentalFee() * INSURANCE_RATE;
    }

    // Calculate damage cost for luxury cars
    @Override            //Polymorphism
    public double calculateDamageCost(double damagePercentage) {
        double totalCost = calculateRentalCost(0); // Total cost including luxury tax
        double damageCost = totalCost * damagePercentage;
        return Math.max(damageCost - calculateInsuranceCost(), 100.0); // Minimum damage cost of $100 if insured
    }
}
