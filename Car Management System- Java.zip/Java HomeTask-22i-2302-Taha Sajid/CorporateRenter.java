//This is a child of Renter class - Inheritance
public class CorporateRenter extends Renter {
    private static final double CORPORATE_RATE = 0.85; // 15% discount

    public CorporateRenter(String renterID, String name, String email, String phoneNumber, String address) {
        super(renterID, name, email, phoneNumber, address);
    }

    // Apply corporate rate
    @Override
    public double calculateDiscount(double rentalCost) {  //Polymorphism
        return rentalCost * CORPORATE_RATE;
    }
}



