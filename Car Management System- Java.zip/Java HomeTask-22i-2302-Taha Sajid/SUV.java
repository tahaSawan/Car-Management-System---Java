// SUV class inheriting from Car
// Subclass for SUV
//SUV is the child of parent class
public class SUV extends Car {
    private static final double INSURANCE_RATE = 0.1; // 10% of base rent

    // Constructor
    public SUV(String carID, String brand, String model, int year, double rentalFee, String plateNumber) {
        super(carID, brand, model, year, rentalFee, plateNumber);
    }

    // Calculate rental cost based on distance traveled
    @Override
    public double calculateRentalCost(double distanceTraveled) {
        return getRentalFee() + distanceTraveled * 0.6; // Cost per km for SUVs predefined formula random value
    }

    // SUVs are insurable
    @Override
    public boolean isInsurable() {
        return true;
    }

    // Calculate insurance cost as a percentage of the base rent
    @Override
    public double calculateInsuranceCost() {
        return getRentalFee() * INSURANCE_RATE;
    }

    // Calculate damage cost for insured and uninsured scenarios
    @Override
    public double calculateDamageCost(double damagePercentage) {      //Polymorphism
        double damageCost = getRentalFee() * damagePercentage;
        // If the car is insured, reduce the damage cost by the insurance amount
        return Math.max(damageCost - calculateInsuranceCost(), 50.0); // Minimum damage cost of $50 if insured
    }
}
