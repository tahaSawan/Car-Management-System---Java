// Abstract class representing a Car   -Example of abstraction
// Base class for Car
public abstract class Car {
    private String carID;
    private String brand;
    private String model;
    private int year;
    private boolean isRented;
    private double rentalFee;
    private String plateNumber;   //All the parameters are private and can only be accessed using getters
    //We have used the concept of encapsulation here - Classes ==encapsulation

    // Constructor
    public Car(String carID, String brand, String model, int year, double rentalFee, String plateNumber) {
        this.carID = carID;
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.isRented = false;
        this.rentalFee = rentalFee;
        this.plateNumber = plateNumber;
    }

    // Getter and Setter methods
    public String getCarID() {
        return carID;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public boolean isRented() {
        return isRented;
    }
  

    // Setter for rental status
    public void setRented(boolean isRented) {
        this.isRented = isRented;
    }

    public void setRentalStatus(boolean status) {
        this.isRented = status;
    }

    public double getRentalFee() {
        return rentalFee;
    }

    public String getPlateNumber() {
        return plateNumber;
    }

    // Abstract methods to be implemented by subclasses
    //User do not need to know the functionality of these functions - Abstraction
    public abstract double calculateRentalCost(double distanceTraveled);

    public abstract boolean isInsurable();

    public abstract double calculateInsuranceCost();

    public abstract double calculateDamageCost(double damagePercentage);
}
