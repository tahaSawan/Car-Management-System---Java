// Frequent Renter subclass
// This is a child of Renter class - Inheritance
public class FrequentRenter extends Renter {
    private static final double DISCOUNT_RATE = 0.1; // 10% discount

    public FrequentRenter(String renterID, String name, String email, String phoneNumber, String address) {
        super(renterID, name, email, phoneNumber, address);
    }

    // Apply discount for frequent renters
    @Override
    public double calculateDiscount(double rentalCost) {   //Ploymorphism
        return rentalCost * (1 - DISCOUNT_RATE);
    }
}
