// RentalTransaction class to handle each rental transaction
public class RentalTransaction {
    private Car car;
    private Renter renter;
    private boolean insuranceAdded;
    private double distanceTraveled;
    private double totalCost;
    private double damagePercentage; // Ensure proper initialization or use

    // Constructor
    public RentalTransaction(Car car, Renter renter, boolean insuranceAdded, double distanceTraveled) {
        this.car = car;
        this.renter = renter;
        this.insuranceAdded = insuranceAdded;
        this.distanceTraveled = distanceTraveled;
        this.totalCost = 0.0;
        this.damagePercentage = 0.0; // Initialize to a default value
    }

    // Calculate the total cost including optional insurance
    public void calculateTotalCost() {
        double baseCost = car.calculateRentalCost(distanceTraveled);
        if (insuranceAdded && car.isInsurable()) {
            baseCost += car.calculateInsuranceCost();
        }
        totalCost = renter.calculateDiscount(baseCost);
        renter.addRentalFee(totalCost);
    }

    // Display the transaction details
    public void displayTransactionDetails() {
        System.out.println("Car: " + car.getBrand() + " " + car.getModel());
        System.out.println("Renter: " + renter.getName());
        System.out.println("Distance Traveled: " + distanceTraveled + " km");
        System.out.println("Insurance Added: " + (insuranceAdded ? "Yes" : "No"));
        System.out.println("Total Cost: $" + totalCost);
    }

    // Calculate and display damage cost upon return
    public void calculateDamageCost(double damagePercentage) {
        this.damagePercentage = damagePercentage; // Properly set the damage percentage
        double damageCost = car.calculateDamageCost(damagePercentage);
        System.out.println("Damage Cost: $" + damageCost);
    }

        // Getters for car and renter
        public Car getCar() {
            return car;
        }
    
        public Renter getRenter() {
            return renter;
        }
}


