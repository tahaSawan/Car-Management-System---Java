import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

// Main class for the Car Rental Management System (CRMS)
public class CRMS {
    private List<Car> cars;
    private List<Renter> renters;
    private List<RentalTransaction> transactions;
    private Scanner scanner;           //This is used for input

    // Constructor
    public CRMS() {
        cars = new ArrayList<>();
        renters = new ArrayList<>();
        transactions = new ArrayList<>();      //Example of Composition - Different class objects here
        scanner = new Scanner(System.in);
    }

    // Main menu
    public void showMenu() {
        while (true) {
            System.out.println("\n--- Car Rental Management System ---");
            System.out.println("1. Car Management");
            System.out.println("2. Renter Management");
            System.out.println("3. Rent Transactions");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    manageCars();
                    break;
                case 2:
                    manageRenters();
                    break;
                case 3:
                    manageRentTransactions();
                    break;
                case 4:
                    System.out.println("Exiting the system.");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Car management submenu
    private void manageCars() {
        while (true) {
            System.out.println("\n--- Car Management ---");
            System.out.println("1. Add Car");
            System.out.println("2. Display Available Cars");
            System.out.println("3. Remove Car");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addCar();
                    break;
                case 2:
                    displayAvailableCars();
                    break;
                case 3:
                    removeCar();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Add a new car
    private void addCar() {
        System.out.print("Enter Car Type (Compact/SUV/Luxury): ");
        String type = scanner.next();
        System.out.print("Enter Car ID: ");
        String carID = scanner.next();
        System.out.print("Enter Brand: ");
        String brand = scanner.next();
        System.out.print("Enter Model: ");
        String model = scanner.next();
        System.out.print("Enter Year: ");
        int year = scanner.nextInt();
        System.out.print("Enter Rental Fee: ");
        double rentalFee = scanner.nextDouble();
        System.out.print("Enter Plate Number: ");
        String plateNumber = scanner.next();

        Car car;
        switch (type.toLowerCase()) {      //Coverts the string to lower case
            case "compact":
                car = new CompactCar(carID, brand, model, year, rentalFee, plateNumber);
                break;
            case "suv":
                car = new SUV(carID, brand, model, year, rentalFee, plateNumber);
                break;
            case "luxury":
                car = new LuxuryCar(carID, brand, model, year, rentalFee, plateNumber);
                break;
            default:
                System.out.println("Invalid car type.");
                return;
        }
        cars.add(car);
        System.out.println("Car added successfully.");
    }

    // Display all available cars
    private void displayAvailableCars() {
        System.out.println("\n--- Available Cars ---");
        for (Car car : cars) {
            if (!car.isRented()) {
                System.out.println("ID: " + car.getCarID() + ", " + car.getBrand() + " " + car.getModel());
            }
        }
    }

    // Remove a car if not rented
    private void removeCar() {
        System.out.print("Enter Car ID to remove: ");
        String carID = scanner.next();
        Car carToRemove = null;

        for (Car car : cars) {
            if (car.getCarID().equals(carID) && !car.isRented()) {
                carToRemove = car;
                break;
            }
        }

        if (carToRemove != null) {
            cars.remove(carToRemove);
            System.out.println("Car removed successfully.");
        } else {
            System.out.println("Car not found or currently rented.");
        }
    }

    // Renter management submenu
    private void manageRenters() {
        while (true) {
            System.out.println("\n--- Renter Management ---");
            System.out.println("1. Add Renter");
            System.out.println("2. Display Renters");
            System.out.println("3. Remove Renter");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addRenter();
                    break;
                case 2:
                    displayRenters();
                    break;
                case 3:
                    removeRenter();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Add a new renter
    private void addRenter() {
        System.out.print("Enter Renter Type (Regular/Frequent/Corporate): ");
        String type = scanner.next();                 //scanner is used to take input
        System.out.print("Enter Renter ID: ");
        String renterID = scanner.next();
        System.out.print("Enter Name: ");
        String name = scanner.next();
        System.out.print("Enter Email: ");
        String email = scanner.next();
        System.out.print("Enter Phone Number: ");
        String phone = scanner.next();
        System.out.print("Enter Address: ");
        String address = scanner.next();

        Renter renter;
        switch (type.toLowerCase()) {
            case "regular":
                renter = new RegularRenter(renterID, name, email, phone, address);
                break;
            case "frequent":
                renter = new FrequentRenter(renterID, name, email, phone, address);
                break;
            case "corporate":
                renter = new CorporateRenter(renterID, name, email, phone, address);
                break;
            default:
                System.out.println("Invalid renter type.");
                return;
        }
        renters.add(renter);
        System.out.println("Renter added successfully.");
    }

    // Display all renters
    private void displayRenters() {
        System.out.println("\n--- Renters ---");
        for (Renter renter : renters) {
            System.out.println("ID: " + renter.getRenterID() + ", Name: " + renter.getName());
        }
    }

    // Remove a renter if they have returned all cars
    private void removeRenter() {
        System.out.print("Enter Renter ID to remove: ");
        String renterID = scanner.next();
        Renter renterToRemove = null;

        for (Renter renter : renters) {
            if (renter.getRenterID().equals(renterID) && renter.getRentedCars().isEmpty()) {
                renterToRemove = renter;
                break;
            }
        }

        if (renterToRemove != null) {
            renters.remove(renterToRemove);
            System.out.println("Renter removed successfully.");
        } else {
            System.out.println("Renter not found or has rented cars.");
        }
    }

    // Rent transaction submenu
    private void manageRentTransactions() {
        while (true) {
            System.out.println("\n--- Rent Transactions ---");
            System.out.println("1. Rent a Car");
            System.out.println("2. Display Transaction Details");
            System.out.println("3. Return Car and Calculate Damage Cost");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    rentCar();
                    break;
                case 2:
                    displayTransactionDetails();
                    break;
                case 3:
                    returnCar();
                    break;
                case 4:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Rent a car to a renter
    private void rentCar() {
        System.out.print("Enter Car ID: ");
        String carID = scanner.next();
        System.out.print("Enter Renter ID: ");
        String renterID = scanner.next();

        Car selectedCar = null;
        Renter selectedRenter = null;

        for (Car car : cars) {
            if (car.getCarID().equals(carID) && !car.isRented()) {
                selectedCar = car;
                break;
            }
        }

        for (Renter renter : renters) {
            if (renter.getRenterID().equals(renterID)) {
                selectedRenter = renter;
                break;
            }
        }

        if (selectedCar == null) {
            System.out.println("Car not available or not found.");
            return;
        }

        if (selectedRenter == null) {
            System.out.println("Renter not found.");
            return;
        }

        System.out.print("Enter Distance Traveled (km): ");
        double distance = scanner.nextDouble();
        System.out.print("Add Insurance (yes/no): ");
        boolean insurance = scanner.next().equalsIgnoreCase("yes");

        RentalTransaction transaction = new RentalTransaction(selectedCar, selectedRenter, insurance, distance);
        transaction.calculateTotalCost();
        transactions.add(transaction);
        selectedCar.setRented(true);
        selectedRenter.addRentedCar(selectedCar);
        System.out.println("Car rented successfully.");
    }

    // Display details of all transactions
    private void displayTransactionDetails() {
        for (RentalTransaction transaction : transactions) {
            transaction.displayTransactionDetails();
        }
    }

    // Return a car and calculate damage cost
    private void returnCar() {
        System.out.print("Enter Car ID: ");
        String carID = scanner.next();
        RentalTransaction transactionToReturn = null;

        for (RentalTransaction transaction : transactions) {
            if (transaction.getCar().getCarID().equals(carID) && transaction.getCar().isRented()) {
                transactionToReturn = transaction;
                break;
            }
        }

        if (transactionToReturn != null) {
            System.out.print("Enter Damage Percentage: ");
            double damagePercentage = scanner.nextDouble();
            transactionToReturn.calculateDamageCost(damagePercentage);
            transactionToReturn.getCar().setRented(false);
            transactionToReturn.getRenter().removeRentedCar(transactionToReturn.getCar());
            System.out.println("Car returned successfully.");
        } else {
            System.out.println("Transaction not found or car not currently rented.");
        }
    }

    // Main method
    public static void main(String[] args) {
        CRMS crms = new CRMS();                   //Object is being created
        crms.showMenu(); 
    }
}

